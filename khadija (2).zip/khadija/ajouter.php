<?php
include "connection.php";
require_once "fuction.php";
$numeros = genererNum();

if (isset($_POST['submit'])) {
    $numero = $_POST['numero'];
    $nom = $_POST['nom'];
    $bud = $_POST['bud'];
    $dd = $_POST['dd'];
    $df = $_POST['df'];
    $s = $_POST['s'];

    $sql = "INSERT INTO `projet`(`id`, `code`, `nom`, `budget`, `date_debut`, `deate_fin`, `statue`) 
    VALUES (NULL,' $numero',' $nom',' $bud',' $dd',' $df',' $s')";
    
    $sresulta = mysqli_query( $coun ,  $sql);

    if ( $sresulta) {
        header("location: index.php?record succeful");
    }
    else {
    echo"failed: " .  mysqli_error($coun);
    }
   
}

?>
<!doctype html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Resto App.</title>
    <link rel="stylesheet" href="bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
</head>

<body>

<div class="jumbotron jumbotron-fluid">

    <div class="container">
        <div class="row">
            <div class="col-md-10 offset-md-1">
                <?php
                if (!empty($message)) {
                    echo "<div  text-center'>$message</div>";
                }
                ?>
                <form method="post" action="ajouter.php">
                    
                    <div class="form-group">
                        <div class="form-group">
                            <label>Numéro de Commande</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">#</div>
                                </div>
                                <input name="numero" value="<?= $numeros ?>" class="form-control" readonly>
                            </div>
                        </div>
                        <div class="form-group">
                            <label>NOM</label>
                            <div class="input-group">
                                <div class="input-group-prepend">

                                </div>
                                <input name="nom" type="text" class="form-control" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label>BUDJET</label>
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <div class="input-group-text">FCFA</div>
                                </div>
                                <input name="bud" type="number"  class="form-control" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label>DATE DEBUT</label>
                            <div class="input-group">
                                <div class="input-group-prepend">

                                </div>
                                <input name="dd" type="date" class="form-control" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label>DATE FIN</label>
                            <div class="input-group">
                                <div class="input-group-prepend">

                                </div>
                                <input name="df" type="date" class="form-control" >
                            </div>
                        </div>
                        <div class="form-group">
                            <label>SITUATION</label>
                            <div class="input-group">
                                <select name="s" class="form-control">
                                    <option >-- Sélectionner une situation --</option>
                                    <option value="1">vrai</option>
                                    <option value="2">faux</option>
                                </select>
                            </div>
                        </div>


                        <div class="form-group">
                            <button name="submit" type="submit" class="btn btn-primary">
                                ajouter
                            </button>
                            <a href="index.php" class="btn btn-outline-danger ml-2">ANNULER</a>
                        </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>

