<?php
$servername="localhost";
$username="root";
$password="";
$dbname="apg";

$coun = mysqli_connect($servername, $username, $password, $dbname);

if (!$coun){
    die(" connection failed" . mysqli_connect_error());
}