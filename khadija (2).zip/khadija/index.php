

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="bootstrap.min.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.2/font/bootstrap-icons.min.css">
    <title>Document</title>
</head>
<body>
    <div class="container">
        <a href="ajouter.php " class="btn btn-dark nb-3">AJOUTER</a>
        <table class="table table-hover texte-center">
  <thead class="table-dark">
    <tr>
      <th scope="col">ID</th>
      <th scope="col">NUMERO PROJET</th>
      <th scope="col">NOM PROJET</th>
      <th scope="col">BUGJET</th>
      <th scope="col">DATE DEBUT</th>
      <th scope="col">DATE FIN</th>
      <th scope="col">SITUATION</th>
      <th scope="col">ACTIONS</th>



    </tr>
  </thead>
  <tbody>
    <?php
    include("connection.php");
    $sql="SELECT * FROM `projet`";
    $sresulta = mysqli_query($coun,$sql);
    while ($row = mysqli_fetch_assoc($sresulta)) {
      ?>
      <tr>
      <td> <?php echo $row['id']?></td>
      <td> <?php echo $row['code']?></td>
      <td> <?php echo $row['nom']?></td>
      <td> <?php echo $row['budget']?></td>
      <td> <?php echo $row['date_debut']?></td>
      <td> <?php echo $row['deate_fin']?></td>
      <td> <?php echo $row['statue']?></td>

      
      <td>
        <a href="edit.php?id=<?php echo $row['id']?>" class="link dark  ml-6"> <i class="bi bi-pencil-fill"></i></i></a>
        <a href="delate.php?id=<?php echo $row['id']?>" class="link dark  ml-6"><i class="bi bi-backspace-fill"></i></a>

      </td>


    </tr>
   

      <?php
    }


    ?>
    
  </tbody>
</table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL" crossorigin="anonymous"></script>
</body>
</html>