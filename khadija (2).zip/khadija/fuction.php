<?php
function genererNum()
{
    $d = 'PRO-' . Date('Yis');
    return $d;
}
function projet($n, $b, $dd, $df, $s)
{
    global $db;
    $N = genererNum();
    $sql = "
        INSERT INTO `projet`(`id`, `code`, `nom`, `budget`, `date_debut`, `deate_fin`, `statue`)
        VALUES(' ','$N','$n','$b', '$dd','$df', '$s')";
    return $db->exec($sql);
}
function getprojet()
{
    global $db;
    $sql = "SELECT * FROM `projet`";
    return $db->query($sql)->fetchAll(2);
}
