<?php
include("connection.php");
$id=$_GET['id'];
$sql = "DELETE FROM `projet` WHERE id = $id";
$sresulta = mysqli_query($coun , $sql);
if ( $sresulta) {
    header("location: index.php?record succeful");
}
else {
echo"failed: " .  mysqli_error($coun);
}
?>